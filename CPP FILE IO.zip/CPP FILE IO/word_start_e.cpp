#include<iostream>
#include<fstream>

using namespace std;

int main()
{
	fstream input;
	string str;
	int count=0;

	input.open("word_start_e.txt", ios::in|ios::out);

	input << "Count the words start with e, Early to bed and early to rise makes a man healthy, wealthy and wise, Eat drink and be merry" << endl;
	input << "Earn and Enjoy" << endl;

	input.seekg(0);

	while(input >> str)
	{
		if(str[0] == 'e')
		{
			count++;
		}
		else
			continue;
	}

	cout << " Counting the number of words that start with 'e' are: " << count << endl;

	return 0;
}
