#include<iostream>
#include<fstream>

using namespace std;

int main()
{
	fstream input;
	string str;
	int count=0;

	input.open("word_end_s.txt", ios::in|ios::out);

	input << "Cunting the words that are end with s, the class’s hours, Joneses states that " << endl;
	input << "Things looks better" << endl;

	input.seekg(0);

	while(input >> str)
	{
//		cout << str << " ";
		int l = str.length() - 1;
//		cout << "end position: " << l << endl << endl;

		if(str[l] == 's')
		{
			//cout << str << " " << endl << "str last char: " << str[l] << endl << endl;
			count++;
		}
		else if(str[l] == ',')
		{
			if(str[l-1] == 's')
			{
				//cout << "last char ," << endl;	
				//cout << str << " " << endl << "str last char: " << str[l] << endl << endl;
				count++;
			}
			else
				continue;
		}
		else
			continue;
	}

	cout << "Counting the number of words that ends with 's' are: " << count << endl;

	return 0;
}
